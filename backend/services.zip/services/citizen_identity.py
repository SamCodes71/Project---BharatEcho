# services/citizen_identity.py
"""
Citizen identity resolution for BharatEcho.

Strategy:
  - Phone calls (Twilio): auto-resolve by phone number — zero caller effort.
  - Web/text sessions: optional CID paste, or link a mobile number.
  - Unknown/new number: offer a 6-digit voice PIN via DTMF (IVR gather).

CID format: BE-{YYYYMMDD}-{6-char uppercase hex hash of E.164 phone}
  Example:   BE-20250324-A3F9C1

The 6-char hash is NOT a security token — it is a short, memorable
reference that links to the citizens table. Phone number is the ground
truth for inbound Twilio calls.
"""

import hashlib
import sqlite3
from datetime import datetime
from typing import Optional, Dict
import random
import string

from backend.routes.data_base import _conn, _row_to_dict, DB_PATH


# ── Schema migration (safe, run at import) ────────────────────────────────────

def _ensure_citizens_schema():
    """
    Add the citizens table and citizen_id columns to calls/complaints
    if they don't already exist. Safe to run on every startup.
    """
    with _conn() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS citizens (
            id           TEXT PRIMARY KEY,
            phone        TEXT UNIQUE,
            name         TEXT,
            lang_code    TEXT DEFAULT 'en',
            pin          TEXT,
            call_count   INTEGER DEFAULT 0,
            created_at   TEXT,
            last_call_at TEXT
        );
        """)

        # Add citizen_id column to calls if not present
        cols_calls = [r[1] for r in db.execute("PRAGMA table_info(calls)").fetchall()]
        if "citizen_id" not in cols_calls:
            db.execute("ALTER TABLE calls ADD COLUMN citizen_id TEXT")

        # Add citizen_id column to complaints if not present
        cols_comp = [r[1] for r in db.execute("PRAGMA table_info(complaints)").fetchall()]
        if "citizen_id" not in cols_comp:
            db.execute("ALTER TABLE complaints ADD COLUMN citizen_id TEXT")


# Run migration immediately on import
_ensure_citizens_schema()


# ── CID generation ────────────────────────────────────────────────────────────

def _generate_cid(phone: str) -> str:
    """
    Deterministic CID from phone + today's date.
    Same phone always produces the same hash suffix.
    The date prefix makes it human-readable and sortable.
    """
    date_str = datetime.utcnow().strftime("%Y%m%d")
    hash_suffix = hashlib.md5(phone.encode()).hexdigest()[:6].upper()
    return f"BE-{date_str}-{hash_suffix}"


def _generate_pin() -> str:
    """6-digit numeric PIN for voice/DTMF identification."""
    return "".join(random.choices(string.digits, k=6))


# ── Core lookup / creation ────────────────────────────────────────────────────

def resolve_citizen(phone: str) -> Dict:
    """
    Look up a citizen by phone number.
    If not found, create a new record and return it.

    Always call this at the start of incoming_call and voice_ws.
    The result can be used to pre-fill ConversationState.

    Returns a dict with keys:
        id, phone, name, lang_code, pin, call_count, is_new
    """
    if not phone or phone in ("Unknown", "Web Browser", ""):
        # Browser session — return a temp identity, no DB write
        return {
            "id": None,
            "phone": phone,
            "name": None,
            "lang_code": "en",
            "pin": None,
            "call_count": 0,
            "is_new": True,
            "open_complaints": [],
        }

    with _conn() as db:
        row = db.execute(
            "SELECT * FROM citizens WHERE phone=?", (phone,)
        ).fetchone()

        if row:
            citizen = dict(row)
            # Increment call count and update last_call_at
            db.execute(
                "UPDATE citizens SET call_count=call_count+1, last_call_at=? WHERE phone=?",
                (datetime.utcnow().isoformat(), phone),
            )
            citizen["call_count"] += 1
            citizen["is_new"] = False
        else:
            # New citizen
            cid  = _generate_cid(phone)
            pin  = _generate_pin()
            now  = datetime.utcnow().isoformat()
            citizen = {
                "id":           cid,
                "phone":        phone,
                "name":         None,
                "lang_code":    "en",
                "pin":          pin,
                "call_count":   1,
                "created_at":   now,
                "last_call_at": now,
                "is_new":       True,
            }
            db.execute(
                "INSERT INTO citizens VALUES (:id,:phone,:name,:lang_code,:pin,"
                ":call_count,:created_at,:last_call_at)",
                {k: citizen[k] for k in
                 ("id","phone","name","lang_code","pin","call_count","created_at","last_call_at")},
            )

    # Attach open complaints so pipeline can reference them
    citizen["open_complaints"] = get_open_complaints(citizen["id"])
    return citizen


def resolve_by_pin(pin: str) -> Optional[Dict]:
    """Look up a citizen by their 6-digit voice PIN."""
    with _conn() as db:
        row = db.execute(
            "SELECT * FROM citizens WHERE pin=?", (pin,)
        ).fetchone()
    if not row:
        return None
    c = dict(row)
    c["open_complaints"] = get_open_complaints(c["id"])
    c["is_new"] = False
    return c


def resolve_by_cid(cid: str) -> Optional[Dict]:
    """Look up a citizen by their full CID string (for web/text chat)."""
    with _conn() as db:
        row = db.execute(
            "SELECT * FROM citizens WHERE id=?", (cid,)
        ).fetchone()
    if not row:
        return None
    c = dict(row)
    c["open_complaints"] = get_open_complaints(c["id"])
    c["is_new"] = False
    return c


# ── Update citizen profile ────────────────────────────────────────────────────

def update_citizen_name(citizen_id: str, name: str):
    """Called once we learn the citizen's name during the complaint flow."""
    if not citizen_id:
        return
    with _conn() as db:
        db.execute(
            "UPDATE citizens SET name=? WHERE id=?", (name, citizen_id)
        )


def update_citizen_lang(citizen_id: str, lang_code: str):
    """Remember language preference for future calls."""
    if not citizen_id:
        return
    with _conn() as db:
        db.execute(
            "UPDATE citizens SET lang_code=? WHERE id=?", (lang_code, citizen_id)
        )


def link_call_to_citizen(call_id: str, citizen_id: str):
    """Write citizen_id onto a call record."""
    if not citizen_id:
        return
    with _conn() as db:
        db.execute(
            "UPDATE calls SET citizen_id=? WHERE id=?", (citizen_id, call_id)
        )


def link_complaint_to_citizen(complaint_id: str, citizen_id: str):
    """Write citizen_id onto a complaint record."""
    if not citizen_id:
        return
    with _conn() as db:
        db.execute(
            "UPDATE complaints SET citizen_id=? WHERE id=?", (citizen_id, complaint_id)
        )


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_open_complaints(citizen_id: Optional[str]) -> list:
    """Return list of open complaint dicts for this citizen."""
    if not citizen_id:
        return []
    with _conn() as db:
        rows = db.execute(
            "SELECT id, category, issue, status FROM complaints "
            "WHERE citizen_id=? AND status NOT IN ('Resolved','Closed') "
            "ORDER BY created_at DESC LIMIT 3",
            (citizen_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def get_citizen_by_id(citizen_id: str) -> Optional[Dict]:
    """Full citizen record by CID."""
    with _conn() as db:
        row = db.execute(
            "SELECT * FROM citizens WHERE id=?", (citizen_id,)
        ).fetchone()
    if not row:
        return None
    c = dict(row)
    c["open_complaints"] = get_open_complaints(citizen_id)
    return c


def get_all_citizens(limit: int = 100) -> list:
    """For admin dashboard — list citizens with call/complaint counts."""
    with _conn() as db:
        rows = db.execute(
            "SELECT c.*, "
            "(SELECT COUNT(*) FROM complaints WHERE citizen_id=c.id) as complaint_count "
            "FROM citizens c ORDER BY c.last_call_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(r) for r in rows]
