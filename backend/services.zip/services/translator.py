# services/translator.py

from backend.services.llm import generate_response

def to_english(text: str) -> str:
    prompt = f"Translate to English:\n{text}"
    return generate_response(prompt, lang_code="en")

def to_hindi(text: str) -> str:
    prompt = f"Translate to Hindi (simple spoken Hindi):\n{text}"
    return generate_response(prompt, lang_code="hi")